CREATE VIEW workerView AS SELECT Worker.id AS id,Person.name AS name,Person.surname AS surname,Person.phone_number AS phone_number,Person.pesel AS pesel,Worker.salary AS salary FROM Worker INNER JOIN Person ON Worker.person_id = Person.id;

