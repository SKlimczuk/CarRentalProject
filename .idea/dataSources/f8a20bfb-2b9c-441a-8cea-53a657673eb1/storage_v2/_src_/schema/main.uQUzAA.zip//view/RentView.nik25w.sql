CREATE VIEW RentView AS SELECT p.pesel as pesel,c.car_brand as brand,c.car_model as model,r.current_mileage as mileage FROM Rent r INNER JOIN Person p ON r.person_id = p.id LEFT OUTER JOIN Car c ON r.car_id = c.id;

