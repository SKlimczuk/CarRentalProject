CREATE VIEW clientView AS SELECT Client.id AS id,Person.name AS name,Person.surname AS surname,Person.phone_number AS phone_number,Person.pesel AS pesel,Client.driving_license AS driving_license FROM Client INNER JOIN Person ON Client.person_id = Person.id;

